/* ═══════════════════════════════════════════════════
   MEDIOMA — Moteur d'Animation Premium v3.0
   Expert : Maxime (Netflix, Airbnb, Stripe)
   8 animations : particules, mandala, texte lettre
   par lettre, lumière cartes, chakras, aura, orbe,
   transition de page
═══════════════════════════════════════════════════ */

(function() {
'use strict';

const reduced = window.matchMedia('(prefers-reduced-motion:reduce)').matches;

// ── 1. CURSEUR PREMIUM ──
function initCursor() {
  if (window.matchMedia('(pointer:coarse)').matches || window.innerWidth <= 900) return;
  const cursor = document.createElement('div');
  cursor.id = 'cursor-dot';
  cursor.innerHTML = '<div class="c-ring"></div><div class="c-dot"></div>';
  document.body.appendChild(cursor);
  const style = document.createElement('style');
  style.textContent = `
    body{cursor:none;}
    #cursor-dot{position:fixed;top:0;left:0;pointer-events:none;z-index:9999;mix-blend-mode:difference;}
    .c-ring{position:absolute;width:36px;height:36px;border:1px solid rgba(212,168,75,.6);border-radius:50%;transform:translate(-50%,-50%);transition:width .4s cubic-bezier(.4,0,.2,1),height .4s cubic-bezier(.4,0,.2,1),opacity .3s;}
    .c-dot{position:absolute;width:5px;height:5px;background:rgba(212,168,75,.9);border-radius:50%;transform:translate(-50%,-50%);}
    #cursor-dot.hover .c-ring{width:56px;height:56px;border-color:rgba(122,90,170,.8);}
    #cursor-dot.click .c-ring{width:24px;height:24px;opacity:.5;}
    a,button,.scard,.cross-card,.mega-item,.hero-cta,.btn{cursor:none;}
  `;
  document.head.appendChild(style);
  let mx=0,my=0,cx=0,cy=0;
  document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;});
  document.addEventListener('mousedown',()=>cursor.classList.add('click'));
  document.addEventListener('mouseup',()=>cursor.classList.remove('click'));
  document.querySelectorAll('a,button,.scard,.cross-card,.hero-cta,.btn').forEach(el=>{
    el.addEventListener('mouseenter',()=>cursor.classList.add('hover'));
    el.addEventListener('mouseleave',()=>cursor.classList.remove('hover'));
  });
  function animCursor(){cx+=(mx-cx)*.12;cy+=(my-cy)*.12;cursor.style.transform=`translate(${cx}px,${cy}px)`;requestAnimationFrame(animCursor);}
  animCursor();
}

// ── 2. PARTICULES COSMIQUES INTERACTIVES ──
function initStars() {
  const container = document.getElementById('stars');
  if (!container) return;
  // Vérifier que le container est visible
  if (!container.offsetParent && container.id !== 'stars') return;
  const canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;';
  container.style.position = 'relative';
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  let W, H, stars = [], mouse = {x:-999, y:-999};
  const COUNT = reduced ? 60 : 180;

  function resize() {
    W = canvas.width = container.offsetWidth;
    H = canvas.height = container.offsetHeight;
  }

  function createStars() {
    stars = Array.from({length: COUNT}, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.8 + 0.2,
      ox: 0, oy: 0,
      depth: Math.random(),
      speed: Math.random() * 0.3 + 0.05,
      phase: Math.random() * Math.PI * 2,
      color: Math.random() > 0.85
        ? `rgba(212,168,75,`
        : Math.random() > 0.5
          ? `rgba(122,90,170,`
          : `rgba(242,234,216,`
    }));
  }

  let scrollY = 0;
  window.addEventListener('scroll', () => { scrollY = window.scrollY; }, {passive:true});
  window.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });

  let t = 0;
  function draw() {
    ctx.clearRect(0, 0, W, H);
    t += 0.008;
    stars.forEach(s => {
      // Scintillement
      const alpha = 0.2 + s.depth * 0.7 * (0.7 + 0.3 * Math.sin(t * s.speed + s.phase));
      // Parallaxe souris
      const dx = mouse.x - s.x;
      const dy = mouse.y - s.y;
      const dist = Math.sqrt(dx*dx + dy*dy);
      const force = Math.max(0, 120 - dist) / 120;
      s.ox += (-dx / dist * force * 2 - s.ox) * 0.08;
      s.oy += (-dy / dist * force * 2 - s.oy) * 0.08;
      // Parallaxe scroll
      const py = scrollY * (1 - s.depth) * 0.15;
      const px = s.x + s.ox;
      const pyr = (s.y + s.oy - py) % H;
      // Dessin
      ctx.beginPath();
      ctx.arc(px, pyr < 0 ? pyr + H : pyr, s.r, 0, Math.PI * 2);
      ctx.fillStyle = s.color + alpha + ')';
      ctx.fill();
      // Halo sur les grandes étoiles
      if (s.r > 1.2) {
        const grd = ctx.createRadialGradient(px, pyr < 0 ? pyr+H : pyr, 0, px, pyr < 0 ? pyr+H : pyr, s.r * 4);
        grd.addColorStop(0, s.color + alpha * 0.4 + ')');
        grd.addColorStop(1, s.color + '0)');
        ctx.beginPath();
        ctx.arc(px, pyr < 0 ? pyr+H : pyr, s.r * 4, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
      }
    });
    requestAnimationFrame(draw);
  }

  try {
    resize();
    createStars();
    draw();
    window.addEventListener('resize', () => { resize(); createStars(); });
  } catch(e) {
    console.warn('MEDIOMA Stars: ', e);
  }
}

// ── 3. ORBE D'ÉNERGIE HERO ──
function initOrb() {
  const hero = document.getElementById('hero');
  if (!hero || reduced) return;
  const orb = document.createElement('div');
  orb.id = 'hero-orb';
  const style = document.createElement('style');
  style.textContent = `
    #hero-orb{
      position:absolute;top:50%;left:50%;
      width:420px;height:420px;
      transform:translate(-50%,-50%);
      pointer-events:none;z-index:0;
      border-radius:50%;
      background:radial-gradient(ellipse at center,
        rgba(212,168,75,.12) 0%,
        rgba(122,90,170,.08) 40%,
        transparent 70%);
      animation:orbPulse 6s ease-in-out infinite;
      will-change:transform,opacity;
    }
    #hero-orb::before{
      content:'';position:absolute;inset:-30px;border-radius:50%;
      background:radial-gradient(ellipse at center,
        rgba(122,90,170,.06) 0%,transparent 70%);
      animation:orbPulse 6s ease-in-out infinite reverse;
    }
    @keyframes orbPulse{
      0%,100%{transform:translate(-50%,-50%) scale(1);opacity:.7;}
      50%{transform:translate(-50%,-50%) scale(1.15);opacity:1;}
    }
  `;
  document.head.appendChild(style);
  hero.style.position = 'relative';
  hero.insertBefore(orb, hero.firstChild);
}

// ── 4. TEXTE LETTRE PAR LETTRE — Slogan hero ──
function initTypewriter() {
  const el = document.querySelector('.hero-promise');
  if (!el || reduced) return;
  const text = el.textContent.trim();
  el.textContent = '';
  el.style.opacity = '1';
  el.style.animation = 'none';
  let i = 0;
  function type() {
    if (i < text.length) {
      const span = document.createElement('span');
      span.textContent = text[i];
      span.style.cssText = `opacity:0;animation:letterIn .4s ease forwards;animation-delay:${i*28}ms;display:inline;`;
      el.appendChild(span);
      i++;
      setTimeout(type, 28);
    }
  }
  const style = document.createElement('style');
  style.textContent = `@keyframes letterIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}`;
  document.head.appendChild(style);
  // Déclencher avec délai pour ne pas bloquer le rendu initial
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setTimeout(type, 800);
        io.disconnect();
      }
    }, {threshold: 0.3});
    io.observe(el);
  } else {
    setTimeout(type, 800);
  }
}

// ── 5. EFFET LUMIÈRE SUR LES CARTES ──
function initCardLight() {
  if (reduced || window.innerWidth <= 700) return;
  const style = document.createElement('style');
  style.textContent = `
    .scard,.cross-card,.tcard{position:relative;overflow:hidden;}
    .scard::before,.cross-card::before,.tcard::before{
      content:'';position:absolute;inset:0;
      background:radial-gradient(circle 200px at var(--mx,50%) var(--my,50%),
        rgba(212,168,75,.12),transparent 70%);
      opacity:0;transition:opacity .4s;pointer-events:none;z-index:1;
    }
    .scard:hover::before,.cross-card:hover::before,.tcard:hover::before{opacity:1;}
  `;
  document.head.appendChild(style);
  document.querySelectorAll('.scard,.cross-card,.tcard').forEach(card => {
    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width * 100).toFixed(1) + '%';
      const y = ((e.clientY - r.top) / r.height * 100).toFixed(1) + '%';
      card.style.setProperty('--mx', x);
      card.style.setProperty('--my', y);
    });
  });
}

// ── 6. CHAKRAS QUI S'ALLUMENT AU SCROLL ──
function initChakraGlow() {
  const rows = document.querySelectorAll('.chakra-row');
  if (!rows.length) return;
  const COLORS = ['#e53030','#e07020','#d4b020','#20a060','#2070c8','#5030a0','#8050c0'];
  const style = document.createElement('style');
  style.textContent = `
    .chakra-row{transition:background .6s ease,border-color .6s ease;}
    .chakra-row.lit{border-left:2px solid var(--chakra-color);}
    .chakra-row.lit img{filter:drop-shadow(0 0 18px var(--chakra-color)) drop-shadow(0 0 8px var(--chakra-color));transition:filter .6s ease;}
  `;
  document.head.appendChild(style);
  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const idx = Array.from(rows).indexOf(entry.target);
        const color = COLORS[idx] || '#d4a84b';
        entry.target.style.setProperty('--chakra-color', color);
        entry.target.classList.add('lit');
        entry.target.style.background = `linear-gradient(to right, ${color}18, transparent)`;
        io.unobserve(entry.target);
      }
    });
  }, {threshold: 0.3});
  rows.forEach(r => io.observe(r));
}

// ── 7. AURA AUTOUR DE LA PHOTO ──
function initAuraPhoto() {
  const wrap = document.querySelector('.about-img-wrap,.about-visual-wrap');
  if (!wrap || reduced) return;
  const style = document.createElement('style');
  style.textContent = `
    .about-img-wrap,.about-visual-wrap{
      position:relative;
    }
    .about-img-wrap::after,.about-visual-wrap::after{
      content:'';position:absolute;inset:-12px;border-radius:inherit;
      background:radial-gradient(ellipse at center,
        rgba(212,168,75,.15) 0%,
        rgba(122,90,170,.1) 50%,
        transparent 70%);
      animation:auraPulse 4s ease-in-out infinite;
      pointer-events:none;z-index:-1;
    }
    @keyframes auraPulse{
      0%,100%{opacity:.6;transform:scale(1);}
      50%{opacity:1;transform:scale(1.04);}
    }
  `;
  document.head.appendChild(style);
}

// ── 8. MANDALA ROTATIF — Page chakras ──
function initMandala() {
  const section = document.querySelector('.chakra-row')?.closest('section') ||
                  document.querySelector('.section-void');
  if (!section || !document.querySelector('.chakra-row') || reduced) return;
  const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('viewBox','0 0 400 400');
  svg.style.cssText = `
    position:absolute;top:50%;left:50%;
    width:min(80vw,600px);height:min(80vw,600px);
    transform:translate(-50%,-50%) rotate(0deg);
    pointer-events:none;opacity:.04;z-index:0;
    will-change:transform;
  `;
  // Dessiner le mandala géométrique
  const cx=200,cy=200;
  let paths = '';
  for(let ring=1;ring<=6;ring++){
    const r = ring*28;
    const petals = ring*6;
    paths += `<circle cx="${cx}" cy="${cy}" r="${r}" stroke="#d4a84b" stroke-width=".8" fill="none"/>`;
    for(let p=0;p<petals;p++){
      const a = (p/petals)*Math.PI*2;
      const x1=cx+r*Math.cos(a), y1=cy+r*Math.sin(a);
      const a2=a+Math.PI*2/petals;
      const x2=cx+r*Math.cos(a2),y2=cy+r*Math.sin(a2);
      paths += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#d4a84b" stroke-width=".5"/>`;
    }
  }
  paths += `<circle cx="${cx}" cy="${cy}" r="8" fill="rgba(212,168,75,.8)"/>`;
  svg.innerHTML = paths;
  section.style.position = 'relative';
  section.style.overflow = 'hidden';
  section.insertBefore(svg, section.firstChild);

  let angle = 0;
  function rotate() {
    angle += 0.12;
    svg.style.transform = `translate(-50%,-50%) rotate(${angle}deg)`;
    requestAnimationFrame(rotate);
  }
  rotate();
}

// ── 9. TRANSITION DE PAGE FLUIDE ──
function initPageTransition() {
  if (reduced) return;
  const overlay = document.createElement('div');
  overlay.id = 'page-transition';
  const style = document.createElement('style');
  style.textContent = `
    #page-transition{
      position:fixed;inset:0;z-index:99999;
      background:linear-gradient(135deg,#181628,rgba(122,90,170,.95));
      pointer-events:none;
      opacity:0;transition:opacity .35s ease;
    }
    #page-transition.out{opacity:1;pointer-events:all;}
  `;
  document.head.appendChild(style);
  document.body.appendChild(overlay);

  // Entrée sur la page — double RAF pour garantir rendu
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      overlay.classList.remove('out');
    });
  });

  // Sortie sur clic de lien interne
  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('http') ||
        href.startsWith('mailto') || href.startsWith('tel') ||
        href.startsWith('//') || link.target === '_blank') return;
    // Ne pas intercepter si même page
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    if (href === currentPage) return;
    link.addEventListener('click', e => {
      e.preventDefault();
      overlay.classList.add('out');
      setTimeout(() => { window.location = href; }, 350);
    });
  });
}

// ── 10. REVEAL STAGGER ──
function initReveal() {
  if (reduced) {
    document.querySelectorAll('.rv').forEach(el => el.classList.add('on'));
    return;
  }
  document.querySelectorAll('.services-grid,.counters-inner,.cross-grid,.footer-inner').forEach(grid => {
    Array.from(grid.children).forEach((child,i) => {
      child.style.transitionDelay = (i * 0.08) + 's';
    });
  });
  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('on');
    });
  }, {threshold:0.08, rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.rv').forEach(el => io.observe(el));
}

// ── 11. COMPTEURS AVEC EASING + PULSE ──
function initCounters() {
  function easeOutQuart(t){return 1-Math.pow(1-t,4);}
  function animateCounter(el) {
    const target = parseInt(el.dataset.target);
    const suffix = target === 100 ? '%' : '+';
    const duration = 2200;
    const start = performance.now();
    function update(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed/duration,1);
      const eased = easeOutQuart(progress);
      el.textContent = Math.floor(eased * target) + suffix;
      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        // Pulse final
        el.style.animation = 'counterPulse .4s ease';
        setTimeout(()=>el.style.animation='',400);
      }
    }
    requestAnimationFrame(update);
  }
  const style = document.createElement('style');
  style.textContent = `@keyframes counterPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}`;
  document.head.appendChild(style);
  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.querySelectorAll('.counter-num').forEach(animateCounter);
        io.unobserve(entry.target);
      }
    });
  }, {threshold:0.3});
  document.querySelectorAll('.counters').forEach(el => io.observe(el));
}

// ── 12. PARALLAXE HERO ──
function initParallax() {
  if (reduced) return;
  const hero = document.getElementById('hero');
  if (!hero) return;
  const cosmic = hero.querySelector('.hero-cosmic');
  const content = hero.querySelector('.hero-content');
  const scrollLine = hero.querySelector('.hero-scroll');
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const sy = window.scrollY;
        if (sy > hero.offsetHeight) { ticking=false; return; }
        if (cosmic) cosmic.style.transform = `translateY(${sy*.25}px)`;
        if (content) content.style.transform = `translateY(${sy*.08}px)`;
        if (scrollLine) scrollLine.style.opacity = Math.max(0, 1-sy/200);
        ticking = false;
      });
      ticking = true;
    }
  }, {passive:true});
}

// ── 13. NAV INTELLIGENTE ──
function initNav() {
  const nav = document.getElementById('nav');
  if (!nav) return;
  let lastScroll=0, hidden=false;
  nav.style.transition='background var(--dur) var(--ease),padding var(--dur) var(--ease),transform .4s cubic-bezier(.4,0,.2,1)';
  window.addEventListener('scroll', () => {
    const sy = window.scrollY;
    nav.classList.toggle('scrolled', sy > 60);
    if (sy > 200) {
      if (sy > lastScroll+10 && !hidden) { nav.style.transform='translateY(-100%)'; hidden=true; }
      else if (sy < lastScroll-5 && hidden) { nav.style.transform='translateY(0)'; hidden=false; }
    } else { nav.style.transform='translateY(0)'; hidden=false; }
    lastScroll = sy;
  }, {passive:true});
}

// ── 14. HAMBURGER + MEGA-DROP ──
function initHamburger() {
  const hbg = document.getElementById('hamburger');
  const mob = document.getElementById('mobile-nav');
  if (!hbg || !mob) return;
  const links = mob.querySelectorAll('a');
  links.forEach(a => { a.style.opacity='0'; a.style.transform='translateY(20px)'; a.style.transition='opacity .4s ease,transform .4s ease'; });
  function openMenu() {
    hbg.classList.add('open'); mob.classList.add('open');
    hbg.setAttribute('aria-expanded','true');
    document.body.style.overflow='hidden';
    links.forEach((a,i) => setTimeout(()=>{ a.style.opacity='1'; a.style.transform='translateY(0)'; },100+i*60));
  }
  function closeMenu() {
    hbg.classList.remove('open');
    links.forEach(a=>{ a.style.opacity='0'; a.style.transform='translateY(10px)'; });
    setTimeout(()=>{ mob.classList.remove('open'); document.body.style.overflow=''; },200);
    hbg.setAttribute('aria-expanded','false');
  }
  hbg.addEventListener('click',()=>hbg.classList.contains('open')?closeMenu():openMenu());
  mob.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
  document.addEventListener('keydown',e=>{ if(e.key==='Escape'&&hbg.classList.contains('open')) closeMenu(); });
}

// ── 15. MEGA-DROP TOUCH & KEYBOARD ──
function initMegaDrop() {
  const triggers = document.querySelectorAll('.has-drop');
  triggers.forEach(trigger => {
    const li = trigger.parentElement;
    trigger.addEventListener('click', e => {
      if (window.innerWidth <= 900) {
        e.preventDefault();
        li.classList.toggle('open');
        triggers.forEach(t=>{ if(t!==trigger) t.parentElement.classList.remove('open'); });
      }
    });
    trigger.addEventListener('keydown', e => {
      if (e.key==='Enter'||e.key===' ') { e.preventDefault(); li.classList.toggle('open'); }
      if (e.key==='Escape') li.classList.remove('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.has-drop'))
      triggers.forEach(t=>t.parentElement.classList.remove('open'));
  });
}

// ── 16. BOUTONS MAGNÉTIQUES ──
function initMagneticButtons() {
  if (reduced || window.innerWidth <= 900) return;
  document.querySelectorAll('.hero-cta,.btn').forEach(btn => {
    btn.addEventListener('mousemove', e => {
      const r = btn.getBoundingClientRect();
      const x = e.clientX-r.left-r.width/2;
      const y = e.clientY-r.top-r.height/2;
      btn.style.transform = `translate(${x*.25}px,${y*.25}px)`;
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform='';
      btn.style.transition='transform .5s cubic-bezier(.4,0,.2,1)';
    });
    btn.addEventListener('mouseenter', () => {
      btn.style.transition='transform .1s ease';
    });
  });
}

// ── 17. BACK TO TOP ──
function initBackTop() {
  const btt = document.getElementById('btt');
  if (!btt) return;
  window.addEventListener('scroll',()=>btt.classList.toggle('show',window.scrollY>400),{passive:true});
  btt.addEventListener('click',e=>{ e.preventDefault(); window.scrollTo({top:0,behavior:'smooth'}); });
}

// ── 18. SMOOTH SCROLL ──
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({behavior:'smooth',block:'start'}); }
    });
  });
}

// ── 19. LIVRE D'OR ──
function initLivreOr() {
  const btn = document.getElementById('submit-review');
  if (!btn) return;
  btn.addEventListener('click', function() {
    const name = document.getElementById('review-name')?.value.trim();
    const text = document.getElementById('review-text')?.value.trim();
    if (!name || !text) { alert('Merci de remplir votre prénom et votre témoignage.'); return; }
    const confirm = document.getElementById('review-confirm');
    if (confirm) confirm.style.display='block';
    if (document.getElementById('review-name')) document.getElementById('review-name').value='';
    if (document.getElementById('review-text')) document.getElementById('review-text').value='';
  });
}

// ── 20. TWINKLE CSS DYNAMIQUE ──
function initTwinkle() {
  if (reduced) return;
  const style = document.createElement('style');
  style.textContent = `
    .star{animation:twinkle-v2 linear infinite;will-change:opacity,transform;}
    @keyframes twinkle-v2{0%{opacity:.05;transform:scale(1)}30%{opacity:.8;transform:scale(1.3)}60%{opacity:.2;transform:scale(.9)}100%{opacity:.05;transform:scale(1)}}
    .rv{transition:opacity 1s cubic-bezier(.4,0,.2,1),transform 1s cubic-bezier(.4,0,.2,1);}
    .scard,.cross-card,.chakra-row{will-change:transform,background;}
  `;
  document.head.appendChild(style);
}

// ══ INIT GLOBAL ══
function init() {
  // Protection globale contre les erreurs
  window.addEventListener('error', e => console.warn('MEDIOMA anim:', e.message));
  initTwinkle();
  initOrb();
  initStars();
  initReveal();
  initCounters();
  initParallax();
  initNav();
  initHamburger();
  initMegaDrop();
  initBackTop();
  initSmoothScroll();
  initChakraGlow();
  initMandala();
  initAuraPhoto();
  initCardLight();
  initPageTransition();
  if (!reduced) initTypewriter();
  if (window.innerWidth > 900) {
    initCursor();
    initMagneticButtons();
  }
  initLivreOr();
  console.log('🌟 MEDIOMA Animations v3.0 — 20 fonctions — Maxime');
}

if (document.readyState==='loading') {
  document.addEventListener('DOMContentLoaded', init);
} else { init(); }

})();
